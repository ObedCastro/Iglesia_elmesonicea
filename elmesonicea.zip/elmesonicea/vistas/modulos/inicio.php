<?php

echo "PÁGINA DE INICIO";