<div class="container">
    <div class="section-title mt-4">
        <h1 class="display-4">Iglesia El mesón ICEA</h1>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-4">
            <h1 class="mb-3">¿Quiénes somos?</h1>
            <h5 class="mb-3">Eos kasd eos dolor vero vero, lorem stet diam rebum. Ipsum amet sed vero dolor sea</h5>
            <p>Takimata sed vero vero no sit sed, justo clita duo no duo amet et, nonumy kasd sed dolor eos diam lorem eirmod. Amet sit amet amet no. Est nonumy sed labore eirmod sit magna. Erat at est justo sit ut. Labor diam sed ipsum et eirmod</p>
            <a href="" class="btn btn-secondary font-weight-bold py-2 px-4 mt-2">Leer más</a>
        </div>
        <div class="col-4">
            <img src="<?php echo $url; ?>vistas/assets/img/iglesia.png" class="w-75" alt="">
        </div>
        <div class="col-4">
            <h1 class="mb-3">Lo que hacemos</h1>
            <p>Invidunt lorem justo sanctus clita. Erat lorem labore ea, justo dolor lorem ipsum ut sed eos, ipsum et dolor kasd sit ea justo. Erat justo sed sed diam. Ea et erat ut sed diam sea ipsum est dolor</p>
            <p class="mb-3"><i class="fa fa-check text-color-primary mr-3"></i> Lorem ipsum dolor sit amet</p>
            <p class="mb-3"><i class="fa fa-check text-color-primary mr-3"></i> Lorem ipsum dolor sit amet</p>
            <p class="mb-3"><i class="fa fa-check text-color-primary mr-3"></i> Lorem ipsum dolor sit amet</p>
            <button class="btn btn-primary font-weight-bold py-2 px-4 mt-2">Leer más</button>
        </div>
    </div>
</div>

<section class="position-relative min-vh-100 mt-5 mb-5 team-work">
  <img src="<?php echo $url; ?>vistas/assets/img/lineas.svg" class="svg-bg position-absolute top-0 start-0 w-100" alt="">
  
  <div class="container section-title position-relative z-1 mt-2">
    <h1 class="display-4">NUESTRO EQUIPO DE TRABAJO</h1>

    <div class="owl-carousel team-carousel overlay-bottom overlay-top py-5 px-4">

        <div class="team-item">
            <div class="team-header">
            <img src="<?php echo $url; ?>vistas/assets/img/testimonial-1.jpg" alt="">
            <div>
                <h4>Nombre Apellido 4</h4>
                <span>Cargo ministerial</span>
            </div>
            </div>
            <p>
            Sed ea amet kasd elitr stet, stet rebum et ipsum est duo elitr eirmod clita lorem.
            Dolor tempor ipsum sanct clita
            </p>
        </div>

        <div class="team-item">
            <div class="team-header">
            <img src="<?php echo $url; ?>vistas/assets/img/testimonial-2.jpg" alt="">
            <div>
                <h4>Nombre Apellido 1</h4>
                <span>Cargo ministerial</span>
            </div>
            </div>
            <p>
            Sed ea amet kasd elitr stet, stet rebum et ipsum est duo elitr eirmod clita lorem.
            Dolor tempor ipsum sanct clita
            </p>
        </div>

        <div class="team-item">
            <div class="team-header">
            <img src="<?php echo $url; ?>vistas/assets/img/testimonial-3.jpg" alt="">
            <div>
                <h4>Nombre Apellido 2</h4>
                <span>Cargo ministerial</span>
            </div>
            </div>
            <p>
            Sed ea amet kasd elitr stet, stet rebum et ipsum est duo elitr eirmod clita lorem.
            Dolor tempor ipsum sanct clita
            </p>
        </div>
        
        <div class="team-item">
            <div class="team-header">
            <img src="<?php echo $url; ?>vistas/assets/img/testimonial-3.jpg" alt="">
            <div>
                <h4>Nombre Apellido 2</h4>
                <span>Cargo ministerial</span>
            </div>
            </div>
            <p>
            Sed ea amet kasd elitr stet, stet rebum et ipsum est duo elitr eirmod clita lorem.
            Dolor tempor ipsum sanct clita
            </p>
        </div>

        <div class="team-item">
            <div class="team-header">
            <img src="<?php echo $url; ?>vistas/assets/img/testimonial-5.jpg" alt="">
            <div>
                <h4>Nombre Apellido 2</h4>
                <span>Cargo ministerial</span>
            </div>
            </div>
            <p>
            Sed ea amet kasd elitr stet, stet rebum et ipsum est duo elitr eirmod clita lorem.
            Dolor tempor ipsum sanct clita
            </p>
        </div>

    </div>

  </div>
</section>



<div class="container-fluid pt-5">
    <div class="container">
        <div class="section-title my-4">
            <!-- <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Háblanos de ti, nos encantará leerte</h4> -->
            <h1 class="display-4">Háblanos de ti, nos encantará saber tu testimonio</h1>
            <span class="text-black-50">También puedes realizarnos consultas, estaremos encantados de poder ayudarte.</span>
            <form class="py-3" action="" method="post" id="formulario-escribenos">
                <input class="mr-3" type="text" placeholder="Nombre" maxlength="30">
                <input class="" type="text" placeholder="Apellido" maxlength="30">
                <br>
                <input class="" type="text" placeholder="Correo electrónico" maxlength="50">
                <br>
                <button type="button" class="btn btn-outline-secondary">Enviar</button>
            </form>
        </div>
        <div class="row">
            
        </div>
    </div>
</div>