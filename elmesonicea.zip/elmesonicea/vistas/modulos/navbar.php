<nav class="navbar navbar-expand-lg position-absolute">
  <div class="container-fluid">

    <!-- Logo izquierda -->
    <a class="navbar-brand fw-bold" href="#">
      <img src="<?php echo $url; ?>vistas/assets/img/logo-iglesia.png" alt="Logo" height="32" class="me-2 logo-nav">
    </a>

    <!-- Toggle mobile -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menú centrado en la página -->
    <div class="collapse navbar-collapse justify-content-center menu-center" id="mainNavbar">
      <ul class="navbar-nav align-items-lg-center">

        <li class="nav-item mx-1">
          <a class="nav-link nav-underline active" href="#">CONÓCENOS</a>
        </li>

        <li class="nav-item mx-1 d-none d-lg-flex">
          <span class="nav-divider"></span>
        </li>

        <li class="nav-item mx-1">
          <!-- <a class="nav-link" href="#">RED</a> -->

            <button type="button" class="nav-link nav-underline popover-menu"
                    data-bs-toggle="popover" data-bs-placement="bottom" 
                    data-bs-html="true"
                    data-bs-custom-class="custom-popover"
                    data-bs-content="
                        <div class='list-group'>
                            <a href='#' class='list-group-item list-group-item-action'>Ministerio Dorcas</a>
                            <a href='#' class='list-group-item list-group-item-action'>Célula familiar</a>
                            <a href='#' class='list-group-item list-group-item-action'>Hospital</a>
                            <a href='#' class='list-group-item list-group-item-action'>Tienda El Encuentro</a>
                            <a href='#' class='list-group-item list-group-item-action'>Jóvenes</a>
                            <a href='#' class='list-group-item list-group-item-action'>Adolescentes</a>
                            <a href='#' class='list-group-item list-group-item-action'>Escuela dominical</a>
                            <a href='#' class='list-group-item list-group-item-action'>Misiones</a>
                        </div>
                    ">
                    RED <i class="fa fa-solid fa-caret-down arrow-menu"></i>
            </button>
        </li>

        <li class="nav-item mx-1 d-none d-lg-flex">
          <span class="nav-divider"></span>
        </li>

        <li class="nav-item mx-1">
          <a class="nav-link nav-underline" href="#">EVENTOS</a>
        </li>

        <li class="nav-item mx-1 d-none d-lg-flex">
          <span class="nav-divider"></span>
        </li>
        
        <li class="nav-item mx-1">
          <a class="nav-link nav-underline" href="#">RECURSOS</a>
        </li>

        <li class="nav-item mx-1 d-none d-lg-flex">
          <span class="nav-divider"></span>
        </li>
        
        <li class="nav-item mx-1">
          <!-- <a class="nav-link nav-underline" href="#">LA FINCA</a> -->

          <button type="button" class="nav-link nav-underline popover-menu" 
                    data-bs-toggle="popover" data-bs-placement="bottom" 
                    data-bs-html="true"
                    data-bs-custom-class="custom-popover"
                    data-bs-content="
                        <div class='list-group'>
                            <a href='#' class='list-group-item list-group-item-action'>Voluntariado</a>
                            <a href='#' class='list-group-item list-group-item-action'>Ingreso al centro de rehabilitación</a>
                            <a href='#' class='list-group-item list-group-item-action'>Actividades sociales</a>
                        </div>
                    ">
                    RED <i class="fa fa-solid fa-caret-down arrow-menu"></i>
            </button>
        </li>

        <li class="nav-item mx-1 d-none d-lg-flex">
          <span class="nav-divider"></span>
        </li>
        
        <li class="nav-item mx-1">
          <a class="nav-link last-item-nav px-2 mx-2" href="#">LEARNING EL MESÓN</a>
        </li>

      </ul>
    </div>

    <!-- Botón derecha -->
    <div class="d-lg-flex">
      <div class="dropdown dropstart">
        <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Idioma
        </button>
        <ul class="dropdown-menu dropdown-menu-white">
            <li><a class="dropdown-item active" href="#">Español</a></li>
            <li><a class="dropdown-item" href="#">Inglés</a></li>
        </ul>
        </div>
    </div>

  </div>
</nav>
