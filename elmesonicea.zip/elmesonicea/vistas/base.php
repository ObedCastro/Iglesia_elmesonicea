<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>ICEA | El Mesón</title>

    <!-- Para mostrar la ruta estática -->
    <?php
        $url = Rutas::mdlRuta(); 
    ?>

    <!-- Favicon -->
    <!-- <link href="vistas/assets/img/favicon.ico" rel="icon"> -->

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- ===================================================== -->

    <link rel="stylesheet" href="<?php echo $url; ?>vistas/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $url; ?>vistas/assets/lib/owl-carousel/assets/owl.carousel.min.css">

    <link href="<?php echo $url; ?>vistas/css/conocenos.css" rel="stylesheet">

</head>
<body>

        <?php

            include "modulos/navbar.php";
            include "modulos/slider.php";
            include "modulos/conocenos.php";
        ?>



    <!-- ======================================================================================= -->

    <!-- Librerías JS -->
    <script src="<?php echo $url; ?>vistas/assets/js/jquery-3.7.1.min.js"></script>
    <script src="<?php echo $url; ?>vistas/assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $url; ?>vistas/assets/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="<?php echo $url; ?>vistas/assets/js/typed.js"></script>

    <script>
        var typed = new Typed('.auto-type', {
            strings: ['Adorar', 'Servir', 'Predicar', 'Vivir para su gloria'],
            typeSpeed: 100,
            backSpeed: 100,
            loop: true
        });

        /* Habilitar popovers */
        const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]');
        const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl));

        /* Sincronizar giro de flecha de menú con popover */
        const popoverTriggers = document.querySelectorAll('.popover-menu');
        popoverTriggers.forEach(trigger => {

        const arrow = trigger.querySelector('.arrow-menu');

        new bootstrap.Popover(trigger, {
            html: true,
            trigger: 'click',
            placement: 'bottom'
        });

        trigger.addEventListener('shown.bs.popover', () => {
            arrow.classList.add('rotate');
        });

        trigger.addEventListener('hidden.bs.popover', () => {
            arrow.classList.remove('rotate');
        });

        });
    </script>


<script>
$(document).ready(function(){
  $('.team-carousel').owlCarousel({
    loop: true,
    margin: 40,
    autoplay: true,
    autoplayTimeout: 6000,
    smartSpeed: 800,
    dots: true,
    nav: false,
    responsive:{
      0:{
        items:1
      },
      768:{
        items:2
      },
      992:{
        items:3
      }
    }
  });
});
</script>

    
    
</body>
</html>